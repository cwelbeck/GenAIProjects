import re

def is_input_safe(user_input):
    """Simple keyword-based filter"""
    banned_keywords = ["hate", "kill", "racist", "bomb", "terrorist"]
    pattern = re.compile("|".join(re.escape(word) for word in banned_keywords), re.IGNORECASE)
    return not bool(pattern.search(user_input))

def censor_response(text):
    """Censor bad words in LLM response"""
    banned_keywords = ["hate", "kill", "racist"]
    for word in banned_keywords:
        text = re.sub(rf"(?i)\\b{word}\\b", "[CENSORED]", text)
    return text
